<?php
session_start();
$username = "";
$email = "";
$password= "";
$errors = [];

$conn = new mysqli("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
$connect = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");


//SIGNUP PAGE
// Sign up error checking
if (isset($_POST['signup-btn'])) 
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    
    if (empty($_POST['username'])) 
    {
        $errors['username'] = 'Username required';
    }
    
    if (empty($_POST['email']))
    {
        $errors['email'] = 'Email required';
    }
    
    if (empty($_POST['password'])) 
    {
        $errors['password'] = 'Password required';
    }
    
    if (isset($_POST['password']) && $_POST['password'] !== $_POST['passwordConf']) 
    {
        $errors['passwordConf'] = 'The two passwords do not match';
    }
    
    // Check if email already exists
    $sql = "SELECT * FROM userVerification WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) 
    {
        $errors['email'] = "Email already exists";
    }
    
    if(count($errors) === 0)
    {
            $username = $_POST['username'];
            $email = $_POST['email'];
            //$token = bin2hex(random_bytes(50)); // generate unique token
            $password= $_POST['password'];
            //$password = password_hash($_POST['password'], PASSWORD_DEFAULT); //encrypt password
            
            
            $_SESSION['id'] = 1;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['password']=$password;
            $_SESSION['verified'] = false;
            $_SESSION['message'] = 'Are you a Robot?';
            $_SESSION['type'] = 'alert-warning';
            header('location: index.php');            
    }
    
    else
    {
    
              $_SESSION['error_msg'] = "Database error: Could not register user";
    }
    
}

//LOGIN PAGE
// Execute when Login btn is pressed
if (isset($_POST['login-btn'])) 
{
    $role= "";

    if (empty($_POST['username'])) 
    {
        $errors['username'] = 'Username or email required';
    }
    
    if (empty($_POST['password']))
    {
        $errors['password'] = 'Password required';
    }
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (count($errors) === 0)
    {
        $query = "SELECT id, username, email, verified, status, password, role FROM userVerification WHERE username=? OR email=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $stmt->bind_result($id, $username, $email, $verified, $status, $password2, $role);

        if ($stmt->execute()) 
        {
            
            $user=$stmt->fetch();
            //$result = $stmt->get_result();
            //$user = $result->fetch_assoc();
            //echo "$password";   
            //echo "$password2";
            
           
            
            if(($verified== true)&&($password == $password2)) // if password matches
            { 
                if($status=='Active')
                {
                        $_SESSION['id'] = 1;
                        $_SESSION['username'] = $username;
                        $_SESSION['email'] = $email;
        
                        if($role== 'User')
                        {
                                header('location: user.php');
                        }
                        
                        else if($role== 'Admin')
                        {
                              header('location: admin.php');  
                        }
                        exit();
                }
                
                else
                {
                        $errors['locked'] = "Sorry, your account has been locked. Please contact Help Desk Support!";
                }
            } 
            
            else // if password does not match
            { 
                $errors['login_fail'] = "Wrong username / password / Not verified";
            }
        } 
        
        else 
        {
            $_SESSION['message'] = "Database error. Login failed!";
            $_SESSION['type'] = "alert-danger";
        }
    }
}

//VERIFICATION PAGE
//Verification of account
if(isset($_POST['che_bt']))
{
        if($_POST['che_val']==$_POST['input_text'])
        {
                $username= $_SESSION['username'];
                $email= $_SESSION['email'];
                $password= $_SESSION['password'];
                $query = "INSERT INTO userVerification SET username=?, email=?, verified=true, status='Active', password=?, role='User'";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('sss', $username, $email, $password);
                $result = $stmt->execute();
                
                
                if ($result) 
                {
                    $user_id = $stmt->insert_id;
                    $stmt->close();
                
                    $_SESSION['correct'] = 'Successful Verification! Please procceed with login';
                    $_SESSION['type'] = 'alert-success';
                    header("Location:login.php");
                }
        }
        else
        {
              session_start();  
              $_SESSION['incorrect'] = 'Incorrect Verification, Please try again!';
              $_SESSION['type'] = 'alert-danger';
        }
}

//ADMIN PAGE
//Deleting of Account by Admin
if(isset($_POST['deletebtn']))
{
        $numberOfCheckbox = count($_POST['records']);
        $i=0;
        while($i<$numberOfCheckbox)
        {
                $keyToDelete= $_POST['records'][$i];
                mysqli_query($conn, "DELETE FROM userVerification WHERE id='$keyToDelete'");
                $i++;
        }
        header("Location: admin.php");
}

if(isset($_POST['search_btn']))
{
        $_SESSION['search_btn']= 1;
        $_SESSION['clear_btn']= 0;
        $_SESSION['date'] = "";
        
        $newDate = date("Y-m-d", strtotime($_POST['date']));  
        
        $pName= $_POST['pName'];
        $level= $_POST['level'];
        $result2= $_POST['result'];
        $date= $newDate;
        
        if(empty($_POST['pName']))
        {
                $pName= 'IS NOT NULL';
                
                
        }
        
        else
        {
               $pName= "='" .$_POST['pName']. "'"; 
          
        }
        
        if(empty($_POST['level']))
        {
                $level= 'IS NOT NULL';
                
        }
        else
        {
                
              $level= "='" .$_POST['level']. "'";
        }
        
        if($_POST['result']=="")
        {
                $result2= 'IS NOT NULL';
                
        }
        
        else if($_POST['result']=='0')
        {
                
              $result2= "='0'";
        }
        else
        {
               $result2= "='" .$_POST['result']. "'";
        }
        
        if(empty($_POST['date']))
        {
                $date= 'IS NOT NULL';
                
        }
        
        else
        {
                
              $date= "LIKE '%".$_POST['date']."%'";
              //$date= "='" .$_POST['date']. "'";
        }
        
        $_SESSION['pName'] = $pName;
        $_SESSION['level'] = $level;
        $_SESSION['result'] = $result2;
        $_SESSION['date'] = $date;
        
        //$query= "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['pName']." AND g.level ".$_SESSION['level']." AND g.result ".$_SESSION['result']." AND g.created_date ".$_SESSION['date']." AND p.doctor_Name= '".$_SESSION['username']."'";
        //echo $query;
        
}

//USER PAGE
//If clear Search btn is pressed in user 
if(isset($_POST['clear_btn']))
{
        $_SESSION['clear_btn']=1;
}

//If Graphical view btn is pressed
if(isset($_POST['graph_btn']))
{
        header("Location: chart.php");
}

//CHART PAGE
//if search btn is pressed
if(isset($_POST['search_graph_btn']))
{
   
        $graphName= "='" .$_POST['graphName']. "'"; 
        $_SESSION['graphName'] = $graphName;
        
        $graphDate= "LIKE '%".$_POST['graphDate']."%'";
        $_SESSION['graphDate'] = $graphDate;
        
        if(isset($_POST['graphName'])&& empty($_POST['graphDate']))
        {
                $_SESSION['option']= 1;
        }
        
        
        else if(isset($_POST['graphName']) && isset($_POST['graphDate']))
        {
                $_SESSION['option']= 2;            
        }
        
       
        //$query1="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND h.date_played ".$_SESSION['graphDate']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='L'";
        //echo $query1;       
}

//if clear btn is pressed
if(isset($_POST['clear_graph_btn']))
{ 
        $graphName= "='1'"; 
        $_SESSION['graphName'] = $graphName;
        
        unset($_SESSION['option']);
        unset($_SESSION['NoName']);
        unset($_SESSION['g3']);
        unset($_SESSION['g4']);
        
        //$query1="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."'";
        //echo $query1;
}


?>