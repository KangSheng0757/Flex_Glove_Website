<?php

    $con = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
    
    $name = $_POST["name"];
    $age = $_POST["age"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $doctor_name = $_POST["doctor_name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];

    $statement = mysqli_prepare($con, "INSERT INTO patients (name, username, age, password,Doctor_name, email, contact) VALUES (?, ?, ?, ?,?,?,?)");
    mysqli_stmt_bind_param($statement, "ssissss", $name, $username, $age, $password,$doctor_name, $email, $phone);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;  
    
    echo json_encode($response);
?>