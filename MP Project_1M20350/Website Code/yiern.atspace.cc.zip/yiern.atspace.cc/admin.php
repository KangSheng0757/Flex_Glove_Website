<?php include 'controllers/authController.php'?>
<?php
session_start();
$conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");

//redirect user to login page if they're not logged in
if (empty($_SESSION['id']))
{   
        header('location: login.php');
        exit();
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Management Page</title>
        <style>
        html
        {
                background:url('Image/background.jpg');
                background-repeat: no-repeat;
                background-size: cover;
                
        }
        </style>
	
</head>
<body style="margin-top: 20px;">

<table border="0" width="1600" align="center" style= "font-size : 20px">
        
                <tr align="right">
                        <th><a href="logout.php" style="color: red; font-size : 30px">Logout</a></th>
                </tr>
</table>

<h1 align="center" style= "font-size : 50px">Welcome back, Admin!</h1>                         

<div class="container">

        <table border="1" width="1000" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:white;">
                                <th>Sr.No</th>
                                <th></th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Current Status</th>
                                <th>Options</th>
                        </tr>
                </thead>
                <tbody>                
                        <?php
                               
                                $query= mysqli_query($conn, "SELECT * FROM userVerification WHERE role= 'User'");
                                
                                $sr=1;
                                while($row= mysqli_fetch_array($query))
                                {?>
                                
                                <tr style="background-color:white;">
                                        <td align="center"><?php echo $sr;?></td>
                                        <td align="center">
                                                <form action="" method="post">
                                                        <input type="checkbox" name="records[]" value="<?php echo $row['id'];?>"/>      
                                                
                                        </td>
                                        <td align="center"><?php echo $row['username'];?></td>
                                        <td align="center"><?php echo $row['email'];?></td>
                                        <td align="center">
                                                <?php 
                                                        if($row['status']== 'Active')
                                                        {
                                                                echo "<p id=sts".$row['id']." style='color: green'>Active</p>";
                                                        }
                                                
                                                        else
                                                        {
                                                                echo "<p id=sts".$row['id']." style='color: red'>Locked</p>";        
                                                        }
                                                ?>
                                        </td>
                                                
                                        
                                        
                                        <td align="center">
                                                <select onChange="active_lock_user(this.value, <?php echo $row['id']; ?>)" style= "font-size : 20px">
                                                <option value= "Select" style= "font-size : 15px">--Select--</option> 
                                                <option value= "Active" style= "font-size : 15px">Active</option>
                                                <option value= "Locked" style= "font-size : 15px">Locked</option>
                                                </select>
                                
                                        </td>
                                       
                                        
                                </tr>
                                 
                                <?php $sr++; 
                                }
                        ?>
                        
                      
                </tbody>
        </table>
        
        <br>
        <div class="row" align="center">
                <div class="form-group">
                        <input type="submit" name="deletebtn" value="Delete User" class="btn btn-info" style= "font-size : 20px; width: 200px; height: 40px;">
                </div>
        </div>
        </form>
</div>

</body>
<script src= "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
        function active_lock_user(val, id)
        {
            $.ajax(
            {
                    type:'post',
                    url:'change.php',
                    data: {val:val, id:id},
                    success: function(result)
                    {
                            if(result=='Active')
                            {
                                    $('#sts'+id).html("Active").css('color','green');
                            }
                         
                            
                            else if(result=='Locked')
                            {
                                    $('#sts'+id).html("Locked").css('color','red');
                            }                                  
                    }
            });
        }
        
</script>
</html>