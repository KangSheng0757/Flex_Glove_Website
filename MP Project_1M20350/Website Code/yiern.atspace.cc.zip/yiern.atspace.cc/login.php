<?php include 'controllers/authController.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="contact-form">
        <?php if (isset($_SESSION['correct'])): ?>
        <div class="alert <?php echo $_SESSION['type'] ?>">
                <?php
                    echo $_SESSION['correct'];
                    unset($_SESSION['correct']);
                    unset($_SESSION['type']);
                  ?>
        </div>
        <?php endif;?>
        
		<img src="Image/avatar.jpg" alt="" class="avatar">
		<h2>Login</h2>
                <?php if (count($errors) > 0): ?>
                        <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                        <li>
                                                <?php echo $error; ?>
					</li>
				<?php endforeach;?>
			</div>
		<?php endif;?>
                
		<form action="login.php" method="post" autocomplete="off">
                        <div class="form-group">
                                <label>Username or Email</label>
                                <input type="text" name="username" class="form-control form-control-lg" value="<?php echo $username; ?>" style="font-size : 20px;">
			</div>
                        
                        <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" style="font-size : 20px;">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" name="login-btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 100%; height: 50px; color: white; background-color: #1E90FF;" >Login</button>
                        </div>
		</form>
                <p style="font-size : 18px;" align="center">Don't have an account yet? <a href="signup.php">Sign up</a></p>
	</div>
</body>
</html>
		
