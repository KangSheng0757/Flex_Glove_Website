<?php
session_start();
session_destroy();
unset($_SESSION['id']);
unset($_SESSION['username']);
unset($_SESSION['email']);
unset($_SESSION['verify']);
unset($_SESSION['pName']);
unset($_SESSION['level']);
unset($_SESSION['result']);
unset($_SESSION['date']);
unset($_SESSION['search_btn']);
unset($_SESSION['clear_btn']);

header("location: login.php");
?>