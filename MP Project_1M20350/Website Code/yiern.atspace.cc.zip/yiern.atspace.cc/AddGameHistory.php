<?php
    $json = file_get_contents('php://input');

    $json_object = json_decode($json,true);

    $finger = $json_object['finger'];
    $degree = $json_object['degree'];
    $result = $json_object['result'];
    $time_spent = $json_object['timespent'];
    $user_id = $json_object['user_id'];
    $level = $json_object['level'];

    $responce = array();

    require_once __DIR__ . '/db_connect.php';

    $my_connection = new DB_CONNECT();
    $my_connection->connect();

    $sql_command = "INSERT INTO game_history(finger,degree,result,time_spent,user_id_fk,level) values ('$finger','$degree','$result','$time_spent','$user_id','$level')";

    $result = mysqli_query($my_connection->myconn,$sql_command);

    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
      //  $response["message"] = "Product successfully created.   ".$sqlCommand;
      $response["message"] = "Product successfully created.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        echo json_encode($response);
        echo("Error description: " . $result -> error);
    }

?>

