<?php
    $con = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
    
    
     $level = $_POST["level"];
     $user_id = $_POST["user_id"];
     
     
    $statement = mysqli_prepare($con, "SELECT count(level) FROM level_history WHERE level = ? AND user_id_fk = ?");
    
    
   
    
    mysqli_stmt_bind_param($statement, "ii", $level, $user_id);
    mysqli_stmt_execute($statement);
    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $level_data);
    
    $response = array();
    
    
    while(mysqli_stmt_fetch($statement)){
        
        $response["level"] = $level_data;
       
    }
    
    echo json_encode($response);
?>