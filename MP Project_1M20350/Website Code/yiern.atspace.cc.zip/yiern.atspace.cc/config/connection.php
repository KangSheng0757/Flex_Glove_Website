<?php

    $conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
    if(!$conn)
    {
            echo "Connection failed";
    }
    
?>