<?php

define('DB_HOST', 'fdb22.atspace.me');
define('DB_USER', '3187553_yiern');
define('DB_PASS', 'tigress222');
define('DB_NAME', '3187553_yiern');

?>