<?php include 'controllers/authController.php'?>
<?php session_start();?>
<?php
 //redirect user to login page if they're not logged in
 if (empty($_SESSION['id']))
 {   
    header('location: login.php');
    exit();
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- Design Format -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="main.css">
  <title>Homepage</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4 home-wrapper">

        <?php if (isset($_SESSION['message'])): ?>
        <div class="alert <?php echo $_SESSION['type'] ?>">
          <?php
            echo $_SESSION['message'];
            unset($_SESSION['message']);
            unset($_SESSION['type']);
          ?>
        </div>
        <?php endif;?>
        
        <?php if (isset($_SESSION['incorrect'])): ?>
        <div class="alert <?php echo $_SESSION['type'] ?>">
          <?php
            echo $_SESSION['incorrect'];
            unset($_SESSION['incorrect']);
            unset($_SESSION['type']);
          ?>
        </div>
        <?php endif;?>

        <h4>Welcome, <?php echo $_SESSION['username']; ?></h4>
        <a href="logout.php" style="color: red">Logout</a>
        <?php if (!$_SESSION['verified']): ?>
          <div class="alert alert-warning alert-dismissible fade show" role="alert">
            You need to verify your account!
            Please key in the number you see on the images provided below in the box
            to verify your account.
          </div><br><br>
          
          
          
          <?php
                $conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
                $query= mysqli_query($conn, "SELECT * FROM var_image ORDER BY RAND() LIMIT 1");
                $result= mysqli_fetch_array($query);
          ?>
          <form method="POST">
         
          <img src="<?php echo $result['image_url'];?>" width="100" height="100"<br>
          <input name="che_val" type="text" value="<?php echo $result['image_val'];?>" hidden="yes">
          <input name="input_text" type="text" required autocomplete="off" maxlength="4">
          <button name="che_bt" type="submit">Check</button>
          </form><br><br>
        <?php else: ?>
          <button class="btn btn-lg btn-primary btn-block">I'm verified!</button>
        <?php endif;?>
      </div>
    </div>
  </div>
</body>
</html>