<?php include 'controllers/authController.php'?>

<?php 
//connection to DB
$servername="fdb22.atspace.me";
$username="3187553_yiern";
$password="tigress222";
$dbname="3187553_yiern";

$conn = new mysqli("$servername","$username","$password","$dbname");

if($conn)
{
	
}

else
{
	echo "Connection Failed";
}
?>

<!DOCTYPE html>
<html>
<head>
<style>
        html
        {
                background:url('Image/background2.jpg');
                background-repeat: no-repeat;
                background-size: cover;
                        
        }
</style>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart()
	{
                var data = google.visualization.arrayToDataTable([
                ['Finger', 'TimeSpent'],
                <?php
                        $query="SELECT * FROM game_history";
                        //$query="SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."'";
                        $res=mysqli_query($conn,$query);
                        while($data=mysqli_fetch_array($res))
                        {
                                $finger=$data['finger'];
                                $time=$data['time_spent'];
                ?>
                                ['<?php echo $finger;?>',<?php echo $time;?>],
                                <?php
                        }
                                ?>
                ]);
        
                var options = 
                {
                        backgroundColor: 'transparent',
                        curveType: 'function',
                        legend: { position: 'bottom' }
                };
        
                var chart = new google.visualization.BarChart(document.getElementById('curve_chart'));
        
                chart.draw(data, options);
      }
</script>
</head>

<body>
<div class="container" style="width:100%;">
        <a href="user.php" style="color: blue; font-size: 20px; font-weight: bold;"> <-- Back</a>
	<h2 align="center" style= "font-size : 30px">Time Spent vs Finger</h2>  
                <form action="chart.php" method="post" autocomplete="off">
                        <table border="0" align="center" style= "font-size : 20px">
                                <thead>
                                        <tr style="background-color:transparent;">
                                                <th>Patient Name:</th>
                                                <th>
                                                        <div class="form-group">
                                                                <input type="text" name="graphName" class="form-control form-control-lg" style="font-size : 20px;  width: 200px;">
                                                        </div>
                                                        
                                                </th>
                                                <th></th>           
                                        </tr>
                                </thead>        
                        </table>
                        
                        <br>
        
                        <table border="0" align="center" style= "font-size : 20px">
                                <thead>
                                        <tr style="background-color:transparent;">
                                                <th>
                                                        <div class="form-group" align="center">
                                                                <button type="submit" name="search_graph_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 100px; height: 30px; color: black;" >Search</button>
                                                        </div>
                                                </th>
                                                
                                                <th style="width: 50px;" ></th>
                        
                                                <th>
                                                        <div class="form-group" align="center">
                                                                <button type="submit" name="clear_graph_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 150px; height: 30px; color: black;" >Clear Search</button>
                                                        </div>
                                                </th>
                                        </tr>
        
                                </thead>
                        </table>
                </form>
  <div id="curve_chart" style="width: 100%; height:400px; font-size : 30px;"></div>
</body>
</html>
