<?php include 'controllers/authController.php'?>
<?php 
//index.php
$connect = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
$query= "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName2']." AND p.doctor_Name= '".$_SESSION['username']."' AND g.side='L'";
$queryR= "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND g.side='R'";
$query1="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='L'";
$query1R="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='R'";
$result = mysqli_query($connect, $query);
$resultR = mysqli_query($connect, $queryR);
$result1 = mysqli_query($connect, $query1);
$result1R = mysqli_query($connect, $query1R);
$chart_data = '';
$chart_dataR='';
$chart_data1='';
$chart_data1R='';
$countL=0;
$totalF1L=0;
$totalF2L=0;
$totalF3L=0;
$totalF4L=0;
$totalF5L=0;

while($row = mysqli_fetch_array($result))
{
	if($row["finger"]==1)
	{
		$totalF1L += $row["result"];
	}
	else if($row["finger"]==2)
	{
		$totalF2L += $row["result"];
	}
	else if($row["finger"]==3)
	{
		$totalF3L += $row["result"];
	}
	else if($row["finger"]==4)
	{
		$totalF4L += $row["result"];
	}
	else if($row["finger"]==5)
	{
		$totalF5L += $row["result"];
	}
	
	$countL++;
}

$averageF1L= ($totalF1L/$countL);
$percentF1L= $averageF1L * 100;

$averageF2L= ($totalF2L/$countL);
$percentF2L= $averageF2L * 100;

$averageF3L= ($totalF3L/$countL);
$percentF3L= $averageF3L * 100;

$averageF4L= ($totalF4L/$countL);
$percentF4L= $averageF4L * 100;

$averageF5L= ($totalF5L/$countL);
$percentF5L= $averageF5L * 100;

echo $percentF5L;



while($row = mysqli_fetch_array($resultR))
{
	$chart_dataR .= "{ timeR:".$row["time_spent"].", finger:'".$row["finger"]."'},  ";
       
}

$chart_dataR = substr($chart_dataR, 0, -2);

while($row = mysqli_fetch_array($result1))
{
	$chart_data1 .= "{ time1:".$row["time_spent"].", date:'".$row["date_played"]."'},  ";
       
}

$chart_data1 = substr($chart_data1, 0, -2);

while($row = mysqli_fetch_array($result1R))
{
	$chart_data1R .= "{ time1R:".$row["time_spent"].", date:'".$row["date_played"]."'},  ";
       
}

$chart_data1R = substr($chart_data1R, 0, -2);

?>

<!DOCTYPE html>
<html>
 <head>
  <title>Line Graph Representation</title>
  <style>
          html
          {
                  background:url('Image/background2.jpg');
                  background-repeat: no-repeat;
                  background-size: cover;
                        
          }
  </style>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script src="config/morris.js"></script>
  <script type="text/javascript">
    google.charts.load("43", {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
		["Thumb", <?php echo $averageF1L?>, "#F50404 " ],
		["Index", <?php echo $averageF2L?>, "#0420F5"],
		["Middle", <?php echo $averageF3L?>, "#10F504 "],
		["Ring", <?php echo $averageF4L?>, "#E603FC "],
		["Pinky", <?php echo $averageF5L?>, "#FC0396 "]
      ]);

      var options = {
        title: "Finger Result",
        width: 600,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.BarChart(document.getElementById("barchart_Left"));
      chart.draw(data, options);
  }
 </script>
 </head>
 <body>
  <div class="container" style="width:100%;">
  <a href="user.php" style="color: blue; font-size: 20px; font-weight: bold;"> <-- Back</a>
   <h2 align="center" style= "font-size : 30px">Time Spent vs Finger (Left)</h2>  
   <h4 align="left" style= "font-size : 20px">Filter Search:</h4>
        <form action="GoogleChart.php" method="post" autocomplete="off">
        <table border="0" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:transparent;">
                                
                                <th>Patient Name:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="text" name="graphName2" class="form-control form-control-lg" style="font-size : 20px;  width: 200px;">
                                        </div>
                                        
                                </th>
                                <th></th>
                              
                        </tr>
                </thead>        
        </table>
        
        
        <br>
        <table border="0" align="center" style= "font-size : 20px">
        <thead>
                <tr style="background-color:transparent;">
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="search_graph_btn2" class="btn btn-lg btn-block" style="font-size : 20px; width: 100px; height: 30px; color: black;" >Search</button>
                                </div>
                        </th>
                        <th style="width: 50px;" ></th>
                        
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="clear_graph_btn2" class="btn btn-lg btn-block" style="font-size : 20px; width: 150px; height: 30px; color: black;" >Clear Search</button>
                                </div>
                        </th>
                </tr>
        
        </thead>
        </table>
        </form>
           <div id="barchart_Left" style="width: 900px; height: 300px; font-size : 30px;"></div>
           <br>
           <br>
           
  </div>
 </body>
</html>
