<?php include 'controllers/authController.php'?>
<?php
session_start();
$conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");

//redirect user to login page if they're not logged in
if (empty($_SESSION['id']))
{   
        header('location: login.php');
        exit();
}
  

?>


<!DOCTYPE html>
<html>
<head>
	<title>Flex Sensor Data Viewing Page</title>
        <style>
        html
        {
                background:url('Image/background2.jpg');
                background-repeat: no-repeat;
                background-size: cover;
                
        }
        </style>
	
</head>
<body style="margin-top: 20px;">

<table border="0" width="1600" align="center" style= "font-size : 20px">
        
                <tr align="right">
                        <th><a href="logout.php" style="color: red; font-size : 30px">Logout</a></th>
                </tr>
</table>

<h1 align="center" style= "font-size : 50px">Welcome back, Dr. <?php echo $_SESSION['username']; ?>!</h1>
<form action="user.php" method="post">
        <div class="form-group" align="center">
                <button type="submit" name="graph_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 160px; height: 30px; color: black;" >Graphical View</button>
        </div>
</form>

<div class="container">

        <h2 align="left" style= "font-size : 20px">Patients' Information:</h2>                         

        <table border="1" width="1000" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:white;">
                                <th>Sr.No</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Email</th>
                                <th>Contact</th>
                               
                        </tr>
                </thead>
                <tbody>                
                        <?php
                               
                                $query= mysqli_query($conn, "SELECT * FROM patients WHERE doctor_Name='".$_SESSION['username']."'");
                                
                                $sr=1;
                                while($row= mysqli_fetch_array($query))
                                {?>
                                
                                <tr style="background-color:white;">
                                        <td align="center"><?php echo $sr;?></td>
                                        <td align="center"><?php echo $row['name'];?></td>
                                        <td align="center"><?php echo $row['age'];?></td>
                                        <td align="center"><?php echo $row['email'];?></td>
                                        <td align="center"><?php echo $row['contact'];?></td>
                                        
                                </tr>
                                 
                                <?php $sr++; 
                                }
                        ?>
                        
                      
                </tbody>
        </table>
        
        <br>
        
        <h4 align="left" style= "font-size : 20px">Filter Search:</h4>
        <form action="user.php" method="post" autocomplete="off">
        <table border="0" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:transparent;">
                                
                                <th>Patient Name:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="text" name="pName" class="form-control form-control-lg" style="font-size : 20px;  width: 200px;">
                                        </div>
                                        
                                </th>
                                <th></th>
                                
                                <th>Level:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="text" name="level" class="form-control form-control-lg" style="font-size : 20px; width: 80px; ">
                                        </div>
                                </th>
                                <th></th>
                                
                                <th>Result:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="text" name="result" class="form-control form-control-lg" style="font-size : 20px;  width: 80px;">
                                        </div>
                                </th>
                                <th></th>
                                
                                <th>Date Attempt:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="date" name="date" class="form-control form-control-lg" style="font-size : 20px; width: 200px;">
                                        </div>
                                </th>
                                    
                        </tr>
                </thead>        
        </table>
        
        
        <br>
        <table border="0" align="center" style= "font-size : 20px">
        <thead>
                <tr style="background-color:transparent;">
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="search_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 100px; height: 30px; color: black;" >Search</button>
                                </div>
                        </th>
                        <th style="width: 50px;" ></th>
                        
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="clear_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 150px; height: 30px; color: black;" >Clear Search</button>
                                </div>
                        </th>
                </tr>
        
        </thead>
        </table>
        </form>
        
        <br>
        
        <h3 align="left" style= "font-size : 20px">Patients' Data:</h3>
        <table border="1" width="1000" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:white;">
                                <th>Sr.No</th>
                                <th>Patient's Name</th>
                                <th>Level</th>
                                <th>Finger</th>
                                <th>Degree</th>
                                <th>Result</th>
                                <th>Time Spent (in sec)</th>
                                <th>Date of Attempt</th>
                                    
                        </tr>
                </thead>
                <tbody>                
                        <?php
                                if(empty($_SESSION['search_btn']))
                                {
                                        $query= mysqli_query($conn, "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.doctor_Name= '".$_SESSION['username']."'");                                   
                                }
                                
                                else
                                {
                                        $query= mysqli_query($conn, "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['pName']." AND g.level ".$_SESSION['level']." AND g.result ".$_SESSION['result']." AND g.created_date ".$_SESSION['date']." AND p.doctor_Name= '".$_SESSION['username']."'");
                                }      
                                
                                if($_SESSION['clear_btn']==1)
                                {
                                        $query= mysqli_query($conn, "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.doctor_Name= '".$_SESSION['username']."'");                                   
                                }
                                
                                $sr=1;
                                while($row= mysqli_fetch_array($query))
                                {?>
                                
                                <tr style="background-color:white;">
                                        <td align="center"><?php echo $sr;?></td>
                                        <td align="center"><?php echo $row['name'];?></td>
                                        <td align="center"><?php echo $row['level'];?></td>
                                        <td align="center"><?php echo $row['finger'];?></td>
                                        <td align="center"><?php echo $row['degree'];?></td>
                                        <td align="center"><?php echo $row['result'];?></td>
                                        <td align="center"><?php echo $row['time_spent'];?></td>
                                        <td align="center"><?php echo $row['created_date'];?></td>
                                        
                                </tr>
                                 
                                <?php $sr++; 
                                }
                        ?>
                        
                      
                </tbody>
        </table>
</div>
</body>
</html>