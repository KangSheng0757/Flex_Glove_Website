<?php include 'controllers/authController.php'?>
<?php 
//index.php
$connect = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");

//Query for first graph
$query= "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND g.side='L'";
$queryR= "SELECT g.*, p.* FROM game_history AS g INNER JOIN patients AS p ON (p.user_id=g.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND g.side='R'";

//Required to fetch the first comparison graph left and right data (Time spent vs Finger)
$result = mysqli_query($connect, $query); 
$resultR = mysqli_query($connect, $queryR);

//Array for the first comparison graph
$chart_data = '';
$chart_dataR='';

//To get the first comparison graph data (Left)
while($row = mysqli_fetch_array($result))
{
	$chart_data .= "{ time:".$row["time_spent"].", finger:'".$row["finger"]."'},  ";     
}

$chart_data = substr($chart_data, 0, -2);

//To get the first comparison graph data (Right)
while($row = mysqli_fetch_array($resultR))
{
	$chart_dataR .= "{ time:".$row["time_spent"].", finger:'".$row["finger"]."'},  ";
       
}

$chart_dataR = substr($chart_dataR, 0, -2);

if($_SESSION['option']==1)
{
        //Query for second graph (initial)
        $queryd= "SELECT DISTINCT date(date_played) as Date, AVG(time_spent) AS t FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='L' Group by Date";
        $querydR= "SELECT DISTINCT date(date_played) as Date, AVG(time_spent) AS t FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='R' Group by Date";
        
        //Required to get the average time spent for the second comparison left and right data (group by date)
        $resultd= mysqli_query($connect, $queryd);
        $resultdR= mysqli_query($connect, $querydR);

        //Array for the second comparison graph initial (group by date)
        $chart_dataD = '';
        $chart_dataDR = '';

        //To get the second comparison graph data (initial left)
        while($row = mysqli_fetch_array($resultd))
        {
                $chart_dataD .= "{ time:".$row["t"].", date:'".$row["Date"]."'},   ";
                $_SESSION['g3']= $chart_dataD;
        }

        //To get the second comparison graph data (initial Right)
        while($row = mysqli_fetch_array($resultdR))
        {
                $chart_dataDR .= "{ time:".$row["t"].", date:'".$row["Date"]."'},   ";
                $_SESSION['g4']= $chart_dataDR;
        }
        
        unset($_SESSION['option']);

}

else if($_SESSION['option']==2)
{     
        echo 'HELLO';
        echo $_SESSION['option'];
        
        //Query for second graph (zoomed in)
        $query1="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND h.date_played ".$_SESSION['graphDate']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='L'";
        $query1R="SELECT h.*, p.* FROM piano_history AS h INNER JOIN patients AS p ON (p.user_id=h.user_id_fk) WHERE p.name ".$_SESSION['graphName']." AND h.date_played ".$_SESSION['graphDate']." AND p.doctor_Name= '".$_SESSION['username']."' AND h.side='R'";
        
        //Required to fetch the second comparison graph left and right data (zoomed in - Time spent for each hands )
        $result1 = mysqli_query($connect, $query1);
        $result1R = mysqli_query($connect, $query1R);
        
        //Array for the second comparison graph (zoomed in to show time frame for the specific date)
        $chart_data1='';
        $chart_data1R='';
        
        //To get the second comparison graph data (Left)
        while($row = mysqli_fetch_array($result1))
        {
                
                $chart_data1 .= "{ time:".$row["time_spent"].", date:'".$row["date_played"]."'},  ";
                $_SESSION['g3']= $chart_data1;
        }

        $chart_data1 = substr($chart_data1, 0, -2);
        
        //To get the second comparison graph data (Right)
        while($row = mysqli_fetch_array($result1R))
        {
                $chart_data1R .= "{ time:".$row["time_spent"].", date:'".$row["date_played"]."'},  ";
                $_SESSION['g4']= $chart_data1R;
        }
        
        $chart_data1R = substr($chart_data1R, 0, -2);
        
        unset($_SESSION['option']);
}

?>

<!DOCTYPE html>
<html>
 <head>
  <title>Line Graph Representation</title>
  <style>
          html
          {
                  background:url('Image/background2.jpg');
                  background-repeat: no-repeat;
                  background-size: cover;
                        
          }
  </style>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
  <script src="config/morris.js"></script>
  
 </head>
 <body>
  <div class="container" style="width:100%;">
  <a href="user.php" style="color: blue; font-size: 20px; font-weight: bold;"> <-- Back</a>
   <h2 align="center" style= "font-size : 30px">Time Spent vs Finger (Left)</h2>  
   <h4 align="left" style= "font-size : 20px">Filter Search:</h4>
        <form action="chart.php" method="post" autocomplete="off">
        <table border="0" align="center" style= "font-size : 20px">
                <thead>
                        <tr style="background-color:transparent;">
                                
                                <th>Patient Name:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="text" name="graphName" class="form-control form-control-lg" style="font-size : 20px;  width: 200px;">
                                        </div>
                                        
                                </th>
                                <th></th>
                                
                                <th>Date Attempt:</th>
                                <th>
                                        <div class="form-group">
                                        <input type="date" name="graphDate" class="form-control form-control-lg" style="font-size : 20px; width: 200px;">
                                        </div>
                                </th>
                                
                                <th></th>
                              
                        </tr>
                </thead>        
        </table>
        
        
        <br>
        <table border="0" align="center" style= "font-size : 20px">
        <thead>
                <tr style="background-color:transparent;">
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="search_graph_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 100px; height: 30px; color: black;" >Search</button>
                                </div>
                        </th>
                        <th style="width: 50px;" ></th>
                        
                        <th>
                                <div class="form-group" align="center">
                                        <button type="submit" name="clear_graph_btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 150px; height: 30px; color: black;" >Clear Search</button>
                                </div>
                        </th>
                </tr>
        
        </thead>
        </table>
        <br><br>
        </form>
   <div id="chart" style= "font-size : 30px;"></div>
   <br>
   <h3 align="center" style= "font-size : 30px">Time Spent vs Finger (Right)</h3> 
   <div id="chartR" style= "font-size : 30px;" ></div>
   <br>
   <h3 align="center" style= "font-size : 30px">Time taken to complete the Piano Game (Left)</h3> 
   <div id="chart1" style= "font-size : 30px;" ></div>
   <br>
   <h3 align="center" style= "font-size : 30px">Time taken to complete the Piano Game (Right)</h3> 
   <div id="chart1R" style= "font-size : 30px;" ></div>
   <br>
   <br>
  </div>
 </body>
</html>

<script>
Morris.Line({
 element : 'chart',
 data:[<?php echo $chart_data;?>],
 xkey:'finger',
 ykeys:['time'],
 labels:['Time Spent for Left Hand(in sec)'],
 pointFillColors: ['#00ff00'],
 lineColors: ['#000000'],
 pointSize: 7,
 lineWidth: 4,
 parseTime:false, 

});

Morris.Line({
 element : 'chartR',
 data:[<?php echo $chart_dataR;?>],
 xkey:'finger',
 ykeys:['time'],
 labels:['Time Spent for Right Hand(in sec)'],
 pointFillColors: ['#00ff00'],
 lineColors: ['#0AAEF3'],
 pointSize: 7,
 lineWidth: 4,
 hideHover:'auto',
 parseTime:false, 

});

Morris.Line({
 element : 'chart1',
 data:[<?php echo $_SESSION['g3'];?>],
 xkey:'date',
 ykeys:['time'],
 xLabelAngle: 1,
 labels:['Average Time Spent in Sec (Left)'],
 pointFillColors: ['#00ff00'],
 lineColors: ['#000000'],
 pointSize: 7,
 lineWidth: 4,
 hideHover:'auto',
 parseTime:false,
 <?php unset($_SESSION['g3']); ?>
});

Morris.Line({
 element : 'chart1R',
 data:[<?php echo $_SESSION['g4'];?>],
 xkey:'date',
 ykeys:['time'],
 xLabelAngle: 1,
 labels:['Average Time Spent in Sec (Right)'],
 pointFillColors: ['#00ff00'],
 lineColors: ['#0AAEF3'],
 pointSize: 7,
 lineWidth: 4,
 hideHover:'auto',
 parseTime:false, 
 <?php unset($_SESSION['g4']); ?>
});
</script>