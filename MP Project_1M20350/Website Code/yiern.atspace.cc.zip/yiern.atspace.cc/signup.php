<?php include 'controllers/authController.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Registration</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
        <link rel="stylesheet" href="style.css">
</head>
<body>
        <div class="contact-form" style="height: 800px;">
                <?php if (count($errors) > 0): ?>
                        <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                        <li>
                                                <?php echo $error; ?>
                                        </li>
                                <?php endforeach;?>
                        </div>
		<?php endif;?>
        
		<img src="Image/avatar.jpg" alt="" class="avatar">
		<h2>Register</h2>
                <form action="signup.php" method="post" autocomplete="off">
                        <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control form-control-lg" value="<?php echo $username; ?>" style="font-size : 20px;">
                        </div>
                
                        <div class="form-group">
                                <label>Email</label>
                                <input type="text" name="email" class="form-control form-control-lg" value="<?php echo $email; ?>" style="font-size : 20px;">
                        </div>
                 
                        <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" style="font-size : 20px;">
                        </div>
                        
                        <div class="form-group">
                                <label>Password Confirm</label>
                                <input type="password" name="passwordConf" class="form-control form-control-lg" style="font-size : 20px;">
                        </div>
                        
                        <div class="form-group">
                                <button type="submit" name="signup-btn" class="btn btn-lg btn-block" style="font-size : 20px; width: 100%; height: 50px; color: white; background-color: #1E90FF;" >Sign Up</button>
                        </div>
                        
		</form>
                <p style="font-size : 18px;" align="center">Already have an account? <a href="login.php">Login</a></p>
        </div>
</body>
</html>
		
