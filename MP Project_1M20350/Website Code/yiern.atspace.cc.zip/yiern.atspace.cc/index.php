<?php include 'controllers/authController.php' ?>
<?php session_start();?>
<?php
        //redirect user to login page if they're not logged in
        if (empty($_SESSION['id']))
        {   
                header('location: login.php');
                exit();
        }
        
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Verification</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
        <link rel="stylesheet" href="style.css">
</head>
<body>
        <div class="contact-form" style="width: 600px; height:700px;">
                <?php if (isset($_SESSION['incorrect'])): ?>
                        <div class="alert <?php echo $_SESSION['type'] ?>">
                                <?php
                                        echo $_SESSION['incorrect'];
                                        unset($_SESSION['incorrect']);
                                        unset($_SESSION['type']);
                                ?>
                        </div>
                <?php endif;?>

                <h4 align="center" style="font-size : 40px; font-weight: bold; color: #ffffff;" >Are you a Robot?</h4>
                <a href="logout.php" style="color: blue; font-size: 20px; font-weight: bold;"> <-- Back</a>
                <?php if (!$_SESSION['verified']): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                You need to verify your account!
                                Please key in the number you see on the images provided below in the box
                                to verify your account.
                        </div><br><br>
                
                <?php
                        $conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern");
                        $query= mysqli_query($conn, "SELECT * FROM var_image ORDER BY RAND() LIMIT 1");
                        $result= mysqli_fetch_array($query);
                ?>
                
                <form method="POST">
                
                <table border="0" align="center" style= "font-size : 20px">
        
                        <tr align="center">
                                <th width="200"><img src="<?php echo $result['image_url'];?>" width="200" height="150"<br></th>
                                <th width="30"></th>
                                <th><input name="che_val" type="text" value="<?php echo $result['image_val'];?>" hidden="yes"></th>
                                <th><input name="input_text" type="text" required autocomplete="off" maxlength="4" style="font-size : 20px; text-align: center;"></th>
                        </tr>
                </table>
                        <button name="che_bt" type="submit" style="font-size : 20px; color: white; font-weight: bold; width: 100%; height: 50px; background-color: #1E90FF">Verify</button>
                
                </form><br><br>
                
                <?php else: ?>
                        <button class="btn btn-lg btn-primary btn-block">I'm verified!</button>
                <?php endif;?>
        </div>
</body>
</html>
		
