<?php
    $json = file_get_contents('php://input');

    $json_object = json_decode($json,true);

    $time_spent = $json_object['TimeSpent'];
    $user_id = $json_object['user_id'];
    $score = $json_object['score'];

    $responce = array();

    require_once __DIR__ . '/db_connect.php';

    $my_connection = new DB_CONNECT();
    $my_connection->connect();

    $sql_command = "INSERT INTO `pianoGame_history`( `date_played`, `Score`, `User_id_fk`) VALUES (CURDATE(),$score,$user_id)";

    $result = mysqli_query($my_connection->myconn,$sql_command);

    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
      //  $response["message"] = "Product successfully created.   ".$sqlCommand;
      $response["message"] = "piano free play successfully inserted.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        echo json_encode($response);
    }

?>
