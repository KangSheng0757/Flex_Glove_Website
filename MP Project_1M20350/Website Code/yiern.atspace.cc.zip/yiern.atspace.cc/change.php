<?php
	$conn = mysqli_connect("fdb22.atspace.me", "3187553_yiern", "tigress222", "3187553_yiern"); 
       
        
        if($_POST['val'] != 'Select')
        {
                $query= mysqli_query($conn, "UPDATE userVerification set status='".$_POST['val']."' WHERE id='".$_POST['id']."' ");
                if($query)
                {
                        $q=mysqli_query($conn, "SELECT * FROM userVerification WHERE id='".$_POST['id']."' ");
                        $data= mysqli_fetch_assoc($q);
                        echo $data['status'];
                }      
        }        
        
?>